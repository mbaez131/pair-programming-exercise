// Write a function within a function taking a random array
// Returning 2 new arrays indicating whether the numbers are odd/even


let numberArray = [2, 4, 7, 11, 15, 16];

function numberSort(arr) {
    let evenNumber;
    let oddNumber;
    for (i = 0; i < arr.length, i++;) {
        if (arr[i] % 2 === 0) {
            evenNumber = evenNumber.push(arr[i])
            return evenNumber
        }
        else {
            oddNumber = oddNumber.push(arr[i])
            return oddNumber
        }
    }
}

console.log("========================")



let vowel = ["a", "e", "i", "o", "u"];

function vowelChecker(x) {
    if (vowel.includes(x)) {
        return "This is a vowel"
    } else if (x == "y") {
        return "This is sometimes a vowel"
    }
    else {
        return "This is not a vowel"
    }
}


console.log("=============================")


function anagrams(firstString, secondString) {
    let firstStringJoined = firstString.split("").join("").sort();
    console.log(firstStringSorted.pop(" "))
    let secondStringJoined = secondString.split("").join("").sort();
    console.log(firstStringSorted)
    console.log(secondStringSorted)
    if (firstStringSorted == secondStringSorted) {
        return true;
    }
    else {
        return false;
    }
}


console.log("=================================")




//Easy 2 

var numArray = [2, 3, 4, 5, 6, 7, 8, 9, 10]

numArray = numArray.filter((number) => {
    for (var i = 2; i <= Math.sqrt(number); i++) {
        if (number % i === 0) return false;
    }
    return true;
});

console.log(numArray);


//Medium 4


let car = {
    make: "Honda",
    model: "Civic Si",
    mileage: "20000",
    color: "red",
    driveToWork: function () {
        let addMile = this.mileage + 33;
        let totMile = addMile + 24000;
        console.log(`Output: old mileage: ${this.mileage} | new mileage: ${addMile}`)
    }, driveAroundTheWorld: function () {
        console.log(`Output: old mileage: ${car.driveToWork} | new mileage: ${totMile} `)
    }, runErrands: function () {
        console.log(`Output: old mileage: ${car.driveAroundTheWorld} | new mileage: ${car.driveAroundTheWorld} `)
    },


}
console.log(car.driveAroundTheWorld())